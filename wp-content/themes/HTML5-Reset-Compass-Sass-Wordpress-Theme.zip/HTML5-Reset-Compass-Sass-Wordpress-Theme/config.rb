# Require any additional compass plugins here.
# Set this to the root of your project when deployed:
http_path = "/"
css_dir = ""
sass_dir = "_/stylesheets"
images_dir = "_/images"
javascripts_dir = "_/javascripts"
# To enable relative paths to assets via compass helper functions. Uncomment:
# relative_assets = true
